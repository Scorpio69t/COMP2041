#!/bin/dash

ls -las "$@"
