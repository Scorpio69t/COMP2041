#!/bin/dash
if test -d /dev/null
then
    echo /dev/null
fi
if test -d /dev
then
    echo /dev
fi
