#!/bin/dash

if [ -d /dev/null ]
then
    echo /dev/null
fi

if [ -d /dev ]
then
    echo /dev
fi
