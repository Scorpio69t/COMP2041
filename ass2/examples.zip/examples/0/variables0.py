#!/usr/bin/python3 -u

a = 'hello'
b = 'world'

print(f"{a} {b}")
