#!/bin/dash
pwd
ls
id
date
