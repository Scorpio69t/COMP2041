#!/bin/dash

echo This   is the   way the world ends
echo This is    the way   the world ends
echo This is the    way    the world       ends
echo Not with a     bang but            a        whimper.
