#!/bin/dash
ls -l /dev/null
