#!/usr/bin/python3 -u

print("This is the way the world ends")
print("This is the way the world ends")
print("This is the way the world ends")
print("Not with a bang but a whimper.")
