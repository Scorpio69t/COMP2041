#!/bin/dash
echo And I told you to be patient
echo And I told you to be fine
echo And I told you to be balanced
echo And I told you to be kind