#!/bin/dash
pwd
