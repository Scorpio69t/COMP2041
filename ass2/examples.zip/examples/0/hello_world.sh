#!/bin/dash

echo hello world
