#!/usr/bin/python3 -u

if 'Andrew' == 'great':
    print('correct')
elif 'Andrew' == 'fantastic':
    print('yes')
else:
    print('error')
