#!/bin/dash
echo 'When old age shall this generation waste,'
echo 'Thou shalt remain, in midst of other woe'
echo 'Than ours, a friend to man, to whom thou sayst,'
echo '"Beauty is truth, truth beauty",  -  that is all'
echo 'Ye know on earth, and all ye need to know.'