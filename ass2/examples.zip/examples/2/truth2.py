#!/usr/bin/python3 -u
print('When old age shall this generation waste,')
print('Thou shalt remain, in midst of other woe')
print('Than ours, a friend to man, to whom thou sayst,')
print('"Beauty is truth, truth beauty",  -  that is all')
print('Ye know on earth, and all ye need to know.')
