#!/usr/bin/python3 -u

row = '1'
while row != '11111111111':
    print(row)
    row = f'1{row}'
