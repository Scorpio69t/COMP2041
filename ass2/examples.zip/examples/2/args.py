#!/usr/bin/python3 -u
import sys

print('My', 'first', 'argument', 'is', sys.argv[1])
print('My', 'second', 'argument', 'is', sys.argv[2])
print('My', 'third', 'argument', 'is', sys.argv[3])
print('My', 'fourth', 'argument', 'is', sys.argv[4])
print('My', 'fifth', 'argument', 'is', sys.argv[5])
