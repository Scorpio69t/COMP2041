#!/usr/bin/python3 -u

import subprocess

subprocess.run(['ls', '-l', '/dev/null'])
