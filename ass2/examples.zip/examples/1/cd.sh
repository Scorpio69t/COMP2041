#!/bin/dash

cd /tmp
pwd
