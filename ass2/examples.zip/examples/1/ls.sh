#!/bin/dash

ls /dev/null
